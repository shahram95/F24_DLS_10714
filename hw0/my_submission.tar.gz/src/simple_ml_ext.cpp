#include <pybind11/pybind11.h>
#include <pybind11/numpy.h>
#include <cmath>
#include <iostream>

namespace py = pybind11;


void softmax_regression_epoch_cpp(const float *X, const unsigned char *y,
								  float *theta, size_t m, size_t n, size_t k,
								  float lr, size_t batch)
{
    /**
     * A C++ version of the softmax regression epoch code.  This should run a
     * single epoch over the data defined by X and y (and sizes m,n,k), and
     * modify theta in place.  Your function will probably want to allocate
     * (and then delete) some helper arrays to store the logits and gradients.
     *
     * Args:
     *     X (const float *): pointer to X data, of size m*n, stored in row
     *          major (C) format
     *     y (const unsigned char *): pointer to y data, of size m
     *     theta (float *): pointer to theta data, of size n*k, stored in row
     *          major (C) format
     *     m (size_t): number of examples
     *     n (size_t): input dimension
     *     k (size_t): number of classes
     *     lr (float): learning rate / SGD step size
     *     batch (int): SGD minibatch size
     *
     * Returns:
     *     (None)
     */

    /// BEGIN YOUR CODE
    
    // Allocate memory for temporary arrays
    float *Z = new float[batch * k];
    float *grad = new float[n * k];
    float *X_batch = new float[batch * n];

    // Process data in batches
    for (size_t i = 0; i < m; i += batch) 
    {
        size_t current_batch = std::min(batch, m - i);

        // Copy current batch of X
        std::memcpy(X_batch, X + i * n, current_batch * n * sizeof(float));

        // Compute Z = X_batch * theta (matmul) 
        for (size_t b = 0; b < current_batch; ++b) 
        {
            for (size_t j = 0; j < k; ++j) 
            {
                Z[b * k + j] = 0;
                for (size_t l = 0; l < n; ++l) 
                {
                    Z[b * k + j] += X_batch[b * n + l] * theta[l * k + j];
                }
            }
        }

        // Compute softmax
        for (size_t b = 0; b < current_batch; ++b) 
        {
            float max_val = *std::max_element(Z + b * k, Z + (b + 1) * k);
            float sum = 0;
            for (size_t j = 0; j < k; ++j) 
            {
                Z[b * k + j] = std::exp(Z[b * k + j] - max_val);
                sum += Z[b * k + j];
            }
            for (size_t j = 0; j < k; ++j) 
            {
                Z[b * k + j] /= sum;
            }
        }

        // Compute gradient
        std::memset(grad, 0, n * k * sizeof(float));
        for (size_t b = 0; b < current_batch; ++b) 
        {
            for (size_t j = 0; j < k; ++j) 
            {
                float coeff = (j == y[i + b]) ? Z[b * k + j] - 1 : Z[b * k + j];
                for (size_t l = 0; l < n; ++l) 
                {
                    grad[l * k + j] += X_batch[b * n + l] * coeff;
                }
            }
        }

        // Update theta
        float scale = lr / current_batch;
        for (size_t j = 0; j < n * k; ++j) 
        {
            theta[j] -= scale * grad[j];
        }

    }

    // Free allocated memory

    delete[] Z;
    delete[] grad;
    delete[] X_batch;

    /// END YOUR CODE
}


/**
 * This is the pybind11 code that wraps the function above.  It's only role is
 * wrap the function above in a Python module, and you do not need to make any
 * edits to the code
 */
PYBIND11_MODULE(simple_ml_ext, m) {
    m.def("softmax_regression_epoch_cpp",
    	[](py::array_t<float, py::array::c_style> X,
           py::array_t<unsigned char, py::array::c_style> y,
           py::array_t<float, py::array::c_style> theta,
           float lr,
           int batch) {
        softmax_regression_epoch_cpp(
        	static_cast<const float*>(X.request().ptr),
            static_cast<const unsigned char*>(y.request().ptr),
            static_cast<float*>(theta.request().ptr),
            X.request().shape[0],
            X.request().shape[1],
            theta.request().shape[1],
            lr,
            batch
           );
    },
    py::arg("X"), py::arg("y"), py::arg("theta"),
    py::arg("lr"), py::arg("batch"));
}
